'''
Tests for API Verification
Created on 21/06/2019

@author: Maruthi Rathnakar
'''
import requests
import logging
import yaml
import os
import json
from APIFunctions.ApiMethods import API


yamlfile_path = os.path.join(os.getcwd(),'Variables\\ApiVariables.yaml')

Dict = yaml.load(open(yamlfile_path),Loader=yaml.FullLoader)

url = Dict['url']
invalidurl = Dict['invalidurl']
headers = json.loads(Dict['headers'])
body = json.loads(Dict['body'])
putbody = json.loads(Dict['putbody'])

def test_getdata1():
    '''Test to verify the data from the get method to the URL
                                 https://jsonplaceholder.typicode.com/posts '''
    print(headers)
    response = API.getData(url,headers)
    data = response.json()
    print(data)
    RecordsCount = len(data)
    assert response.status_code == 200
    assert RecordsCount >= 100
    for i in range(RecordsCount):
        assert 'userId' in data[i].keys()
        assert 'id' in data[i].keys()
        assert 'title' in data[i].keys()
        assert 'body' in data[i].keys()


def test_getdata2():
    '''Test to verify the data from the get method to the URL
                                   https://jsonplaceholder.typicode.com/posts/1 '''
    requiredurl = API.prepareurl(url,1)
    response = API.getData(requiredurl,headers)
    data = response.json()
    RecordsCount = len(data)
    assert response.status_code == 200
    assert RecordsCount == 1
    assert 'userId' in data.keys()
    assert 'id' in data.keys()
    assert 'title' in data.keys()
    assert 'body' in data.keys()

def test_getdata3():
    '''Test to verify the data from the get method to the invalid URL
                                 https://jsonplaceholder.typicode.com/invalidposts '''
    logging.getLogger().setLevel(logging.DEBUG)
    requests_log = logging.getLogger("requests.packages.urllib3")
    requests_log.setLevel(logging.DEBUG)
    requests_log.propagate = True
    response = API.getData(invalidurl,headers)
    status_code = response.status_code
    data = response.json()
    RecordsCount = len(data)
    assert response.status_code == 404
    assert RecordsCount == 0
    logging.debug("Response: Status code: %d", response.status_code)
    logging.debug("Request: %s %s %s", response.request.method, response.request.url, response.request.body)


def test_postdata():
    '''Test to verify the data from the Post method to the URL
                    https://jsonplaceholder.typicode.com/posts '''
    response = API.postData(url,body,headers)
    data = response.json()
    assert response.status_code == 201
    assert 'userId' in data.keys()
    assert data['userId'] == 1
    assert 'id' in data.keys()
    assert data['id'] == 101
    assert 'title' in data.keys()
    assert data['title'] == 'foo'
    assert 'body' in data.keys()
    assert data['body'] == 'bar'

def test_putdata():
    '''Test to verify whether we can put the data using Put method through the URL
                        https://jsonplaceholder.typicode.com/posts/1 '''
    requiredurl = API.prepareurl(url, 1)
    response = API.putdata(requiredurl,putbody,headers)
    data = response.json()
    assert response.status_code == 200
    assert 'userId' in data.keys()
    assert data['userId'] == 1
    assert 'id' in data.keys()
    assert data['id'] == 1
    assert 'title' in data.keys()
    assert data['title'] == 'abc'
    assert 'body' in data.keys()
    assert data['body'] == 'xyz'

def test_deletedata():
    '''Test to verify whether we can delete the data using delete method through the URL
                            https://jsonplaceholder.typicode.com/posts/1 '''
    requiredurl = API.prepareurl(url, 1)
    response = API.deletedata(requiredurl,headers)
    data = response.json()
    assert response.status_code == 200

test_putdata()
'''
Methods used by Tests for API Verification
Created on 21/06/2019

@author: Maruthi Rathnakar
'''
import requests
import json
from requests.models import PreparedRequest

class API():

    def prepareurl(URL,data):
        """
        Method which prepares required url from the base url
        :param URL: the base URL
        :param data: data to append to the base URl
        """
        NEWURl = URL + '/' + str(data)
        return NEWURl

    def getData(url,headers):
        """
        Method which calls Requests GET method and returns the response
        :param URL: the base URL
        :param headers: headers
        """
        response = requests.get(url,headers=headers)
        return response

    def postData(url,body,headers):
        """
        Method which calls Requests POST method and returns the response
        :param URL: the base URL
        :param body: Body mostly in json format
        :param headers: headers
        """
        response = requests.post(url,data=json.dumps(body),headers=headers)
        return response

    def putdata(url,body,headers):
        """
        Method which calls Requests PUT method to insert anyt record and returns the response
        :param URL: the base URL
        :param body: Body mostly in json format
        :param headers: headers
        """
        response = requests.put(url, data=json.dumps(body), headers=headers)
        return response

    def deletedata(url,headers):
        """
        Method which calls Requests DELETE method to delete any record and returns the response
        :param URL: the base URL
        :param headers: headers
        """
        response = requests.delete(url, headers=headers)
        return response